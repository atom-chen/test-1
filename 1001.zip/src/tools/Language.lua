	
local Language = {}

-- 游戏页面
Language["Relive"]               = "复活"

-- 游戏中的新手引导
Language["ClickToStart"]         = "点击开始"
Language["ClickSkillBtn"]        = "点击技能"
Language["ClickToBuildTower"]    = "点击造塔"

Language["TestNewName"]          = "测试一下热更新lua文件"

-- 第三模式用到
Language["ManslaughterElves"]    = "误杀逃跑精灵:"
-- 14-3
Language["TreasuresCount"]       = "守护宝物数量:"
Language["TreasuresRobbed"]      = "糟糕宝物被抢"
Language["TreasuresSucceed"]     = "恭喜守护成功"
Language["Treasures"]            = "宝物"
-- 7-3
Language["KillAElves"]           = "警报: 误杀了一名逃跑的精灵"
-- 9-3
Language["FaZhenCountdown"]      = "法阵倒计时"
-- 10-3
Language["CollectedEssence"]     = "收集精华数量:"
Language["Essence"]              = "精华"
-- 12-3
Language["KillMonsterCount"]     = "杀怪:"

-- 5种天气名字，用来做英雄的某个技能受天气的影响增强的时候，弹出tips的时候用到
Language["SunName"]              = "晴天"
Language["NightName"]            = "夜晚"
Language["RainName"]             = "雨天"
Language["SnowName"]             = "雪天"
Language["WindName"]             = "风天"
-- Language["Affect"]               = "受"
-- Language["Affect"]               = "受"

-- 游戏中的塔天赋页面
Language["Talent"]               = "天赋"
Language["CurrentEff"]           = "当前效果"
Language["NextLvEff"]            = "下级效果"
Language["NotLearn"]             = "还未学习"
Language["FullLevel"]            = "已经满级"

-- 英雄通过钻石立刻复活页面
Language["Cost"]                 = "消耗"
Language["ReliveImmediately"]    = "立刻复活"
Language["Cancel"]               = "取 消"

-- 游戏中的暂停页面
Language["Continue"]             = "继续"
Language["Restart"]              = "重  玩"
Language["Home"]                 = "首页"
Language["Music"]                = "音乐"
Language["SoundEffect"]          = "音效"
Language["Vibration"]            = "震动"

-- 游戏中的结算页面
Language["NextLevel"]            = "下一关"
Language["Back"]                 = "返  回"
     
-- 游戏中的InfoPanel     
Language["WaveMonster"]          = "波"
     
-- 英雄大厅     
Language["HeroLevelUp"]          = "英雄升级"
Language["UpStar"]               = "升阶"
Language["Confirm"]              = "确 认"
Language["Outline"]              = "概述"
Language["Attributes"]           = "属性"
Language["HeroDesc"]             = "人物简介"
     
-- 关卡难度选择界面     
Language["ModelLevel"]           = "关卡"
Language["Group"]                = "羁绊"
Language["Detail"]               = "详细"
Language["ThroughCondition"]     = "通关条件"
Language["Easy"]                 = "简单"
Language["Hard"]                 = "困难"
Language["BeginToBattle"]        = "开始战斗"
Language["heroInfo"]             = "关键字:" 
Language["chooseBegin"]          = "开始"
Language["title"]                = "通关条件"     
Language["skillName"]            = "羁绊技能"
Language["rePlay"]               = "重玩"
Language["menu"]                 = "离开"
Language["exit"]                 = "退出"
Language["active"]               = "已激活"
Language["noActive"]             = "未激活"
Language["cooling"]              = "冷却时间:"
Language["forever"]              = "永久"
Language["second"]               = "秒"
Language["sign"]                 = "￥"

--大厅使用
Language["Health"]        = "生命值:"
Language["Defensive"]    = "防御力:"
Language["Attack"]       = "攻击力:"
Language["SRange"]       = "近战射程:"
Language["LRange"]       = "远程射程:"
Language["MRate"]        = "近战攻击频率:"
Language["RRate"]        = "远程攻击频率:"
Language["Speed"]        = "移动速度:"
Language["CPower"]       = "暴击威力:"
Language["DRate"]        = "闪避率:"
Language["LDrain"]       = "普攻吸血:"
Language["TEffect"]      = "治疗效果:"
Language["CRate"]        = "暴击率:"
Language["Resistance"]   = "抵抗力:"

Language["Buy"]          = "购买"
Language["Unlock"]       = "查看解锁"
Language["Rate"]         = "秒/次"
Language["updata"]       = "升阶"
Language["continue"]     = "继续"
Language["get"]          = "领取"
Language["hero"]         = "英雄"
Language["give"]         = "内赠"
Language["full"]         = "已满阶"
Language["store"]        = "初始一阶，最大可进化至五阶"
Language["upTips"]       = "进阶奖励"
Language["package_1"]    = "每日礼包"
Language["package_2"]    = "超值礼包"
Language["buySuccess"]   = "购买成功"
Language["buyStr_1"]     = "恭喜获得"
Language["diamond"]      = "钻石"
Language["netWork"]      = "网络未连接"
return Language
